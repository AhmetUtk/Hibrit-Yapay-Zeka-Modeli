import pandas as pd
data = pd.read_csv("güncellenmişSon1.csv")
data=data.drop(["Unnamed: 0","second","src","dst"],axis=1)

print(data.head(30))
print(data.shape)
print(data.info())

label1data=data[data["label"]==1]
label0data=data[data["label"]==0]
selectedData=label1data.sample(n=1230,random_state=42)
data=pd.concat([selectedData,label0data])



