import pandas as pd

# CSV dosyasının adını ve yolunu belirtin
dosya_adı = 'güncellenmişSon.csv'

# CSV dosyasını pandas DataFrame'e yükle
df = pd.read_csv(dosya_adı, delimiter=',')  # Ayırıcıyı uygun şekilde ayarlayın

# Dönüştürülecek kolonun adını belirtin
hedef_kolon = 'wpan_fcs'

# Ondalık tabana çevirme işlemi
df[hedef_kolon] = df[hedef_kolon].apply(lambda x: int(x, 16))

# Güncellenmiş DataFrame'i yazdır
print("Güncellenmiş DataFrame:")
print(df)

# Güncellenmiş DataFrame'i yeni bir CSV dosyasına yaz
çıktı_dosya_adı = 'güncellenmişSon1.csv'
df.to_csv(çıktı_dosya_adı, index=False, sep=',')  # Ayırıcıyı uygun şekilde ayarlayın

print(f'Veri seti güncellendi ve "{çıktı_dosya_adı}" dosyasına yazıldı.')
