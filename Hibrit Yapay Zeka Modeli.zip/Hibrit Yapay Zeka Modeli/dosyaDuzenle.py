# Dosya adını ve yolunu belirtin
dosya_adı = 'son.csv'

# Dosyayı oku ve içeriği değiştir
with open(dosya_adı, 'r', encoding='utf-8') as dosya:
    dosya_içeriği = dosya.read()

# ";" karakterlerini "," ile değiştir
dosya_içeriği = dosya_içeriği.replace(';', ',')

# Değiştirilmiş içeriği dosyaya yaz
with open(dosya_adı, 'w', encoding='utf-8') as dosya:
    dosya.write(dosya_içeriği)

print(f'Dosyadaki ";" karakterleri "," ile değiştirildi: {dosya_adı}')
